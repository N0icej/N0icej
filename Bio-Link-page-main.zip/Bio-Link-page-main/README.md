# Bio-Link-page
Just a simple Bio Page with random music on play and some other features, to change Discord prescence use https://status.gg

![image](https://github.com/Sye0001/Bio-Link-page/assets/119392569/e6152b7e-2069-491a-bcc5-158f0f36e6c0)
